<?php
$servername="localhost";
$username="root";
$password="";
$database="data";

$conn=mysqli_connect($servername,$username,$password,$database);

if(!$conn)
{
    echo "no connection";
}
else 
{
echo "";
}
?>