<?php
include 'connection.php';
ini_set('display_errors', 1);

if(isset($_POST['button']))
{
    $date = date("Y-m-d");
    $dt= date('Y-m-d', strtotime($date. ' -2 days'));
 echo $searchh=urlencode(strtolower($_POST['searchinput']));

 $queryw="select * from channels where keyword='$searchh' and date>=$dt";
 $resultw=mysqli_query($conn,$queryw);
 if(mysqli_num_rows($resultw)>0)
 {
    header("Location: csv.php?searchinput=".$roww['keyword']);
 }else{
    header("Location: postdata.php?searchinput=".$_POST['searchinput']);
 }
 /*while($roww=mysqli_fetch_assoc($resultw))
 {
    if(mysqli_num_rows($resultw)>0)
    {
                       $date=$roww['date'];
                       $currentdate =date("Y-m-d");
                       $diff = abs(strtotime($date) - strtotime($currentdate));
                         if($searchh==$roww['keyword'] && $diff<=2)
                        {
                            header("Location: csv.php?searchinput=".$roww['keyword']);
                        }
                        else{
                            header("Location: postdata.php?searchinput=".$_POST['searchinput']);
                        }
                    }

                   else{                          
                    header("Location: postdata.php?searchinput=".$_POST['searchinput']);
                    echo "empty";
                   }
}*/

     /*$queryw="select * from channels";
                $resultw=mysqli_query($conn,$queryw);
                while($roww=mysqli_fetch_assoc($resultw))
                {
               
                    if(mysqli_num_rows($resultw)>0)
                    {
                        if($searchh==$roww['keyword'])
                        {
                            header("Location: csv.php?searchinput=".$roww['keyword']);
                        }
                        else{
                            header("Location: postdata.php?searchinput=".$_POST['searchinput']);
                        }
                    }

                   else{                          
                    header("Location: postdata.php?searchinput=".$_POST['searchinput']);
                    echo "empty";
                   }
            }*/
  
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
<body>
    <div class="container">
    <div class="row">
    <div class="col-sm-4"></div>
    <div class="col-sm-4">
    <br><br<br><br><br><br>
    <form method="post" action="">
  <div class="form-group">
  
   <i class="fa fa-youtube-play" style="font-size:48px;color:red"></i>
   <input name="searchinput" type="test" class="form-control" placeholder="Enter keyword">
</div>
    </br>
   
<button name="button" type="submit" class="btn btn-secondary">FETCH </button>
</br>
<small id="emailHelp" class="form-text text-muted">*It may take 1-2 hours per keyword to fetch data in csv </small>
</form></div>
    <div class="col-sm-4">
    
    </div>
    </div>
    </div>
</body>
</html>