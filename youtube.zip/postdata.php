<?php
include 'connection.php';
$search=$_GET['searchinput'];
set_time_limit(0);
ini_set('display_errors', 1);
$querywy="SELECT * FROM  channels ";
$resultwy=mysqli_query($conn , $querywy);

  function channelAbout($channelid,$conn){
    $url="https://www.youtube.com/channel/".$channelid."/about";
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('User-Agent: "Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US; rv:1.9.0.15) Gecko/2009101601 Firefox/3.0.15 GTB6 (.NET CLR 3.5.30729)"' ));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    $html = curl_exec($ch);
    $first = explode("ytInitialData = {",$html);
    $second = explode(";</script>",$first[1]);
    $result = '{'.$second[0];    //contains json
    $resultwww = json_decode($result , true);
    
    $meta=$resultwww['metadata']['channelMetadataRenderer'];
      $channelname=mysqli_real_escape_string($conn , $meta['title']);
    
     $channelabout=mysqli_real_escape_string($conn , $meta['description']);
    
     preg_match_all("/[\._a-zA-Z0-9-]+@[\._a-zA-Z0-9-]+/i", $channelabout, $matches);
    foreach($matches[0] as $email) {
      $email."<br>";
    }
    
    preg_match_all('/[\+]?\d{12}|\d{10}|\d{11}|\(\d{3}\)\s?-\d{6}/',$channelabout,$catches);
    foreach($catches[0] as $number) {
      $number."<br>";
    }
    
    
    $ddd=$resultwww['contents']['twoColumnBrowseResultsRenderer']['tabs'][5]['tabRenderer']['content']
    ['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['channelAboutFullMetadataRenderer']['primaryLinks'];
    
    if(empty($ddd))
    {
        $ddd=$resultwww['contents']['twoColumnBrowseResultsRenderer']['tabs'][6]['tabRenderer']['content']
        ['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['channelAboutFullMetadataRenderer']['primaryLinks']; 
    }
    
    foreach($ddd as $meta)
    {
        $link=$meta['navigationEndpoint']['urlEndpoint']['url'];
        
        if(strpos($link, "facebook") !== false)
        {
            $array[0]=$link;
        }
        elseif(strpos($link, "twitter") !== false)
        {
            $array[1]=$link;
        }
        elseif(strpos($link, "instagram") !== false)
        {
            $array[2]=$link;
        }
    }
    
    $subscribersss=mysqli_real_escape_string($conn , str_replace('subscribers','',$resultwww['header']['c4TabbedHeaderRenderer']['subscriberCountText']['simpleText']));
    $word = "M";
    $wordd = "K";
    
    
    
    if(strpos($subscribersss, $word) !== false){
    $subscriberss=str_replace('M','',$subscribersss);
     $subscribers=$subscriberss*1000000;
    
    } 
    elseif(strpos($subscribersss, $wordd) !== false)
    {
    $subscriberss=str_replace('K','',$subscribersss);
    $subscribers=$subscriberss*1000;
    
    }
    
    else{
      $subscribers=$subscribersss;
    }
    $ceta=$resultwww['contents']['twoColumnBrowseResultsRenderer']['tabs'][5]['tabRenderer']['content']
      ['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]
      ['channelAboutFullMetadataRenderer'];
    
    $location=$resultwww['contents']['twoColumnBrowseResultsRenderer']['tabs'][5]['tabRenderer']['content']
    ['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents']
    [0]['channelAboutFullMetadataRenderer']['country']['simpleText'];
    
    
    $query="SELECT * FROM channels WHERE channelid='$channelid'";
    $result=mysqli_query($conn , $query);
    
    if(mysqli_num_rows($result)<=0)
    {
        $sql="insert into channels set location='$location',
        subscribers='$subscribers',phoneno='$number',email='$email',channelabout='$channelabout',channelname='$channelname',
        fblink='$array[0]' , twitterlink='$array[1]',instalink='$array[2]'";
        $result=mysqli_query($conn , $sql);
      
    }
    else{
     $sql="update channels set location='$location',
     subscribers='$subscribers',email='$email',phoneno='$number',channelabout='$channelabout',channelname='$channelname',
     fblink='$array[0]' , twitterlink='$array[1]',instalink='$array[2]'  where channelid='$channelid' ";
     $result=mysqli_query($conn , $sql);
    
    }
    }
    function  renderDivData($masterListgh,$rty,$key,$resultwwwss,$UserChannel,$conn)
    {
    $url = "https://www.youtube.com/youtubei/v1/search?key=".$key;
    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
      
    $headers = array(
         "authority: www.youtube.com",
         "x-origin: https://www.youtube.com",
         "sec-ch-ua-mobile: ?0",
         "authorization: SAPISIDHASH 1617691435_a72f9a06df2d69beec9df72442e341185fb98639",
         "content-type: application/json",
         "user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36",
         "x-youtube-client-name: 1",
         "x-youtube-client-version: 2.20210404.08.00",
         "x-goog-authuser: 0",
         "x-goog-visitor-id: CgtpY3RPb3h1V1ZFMCibhrCDBg%3D%3D",
         "accept: */*",
         "origin: https://www.youtube.com",
         "x-client-data: CJe2yQEIpbbJAQjBtskBCKmdygEIlqzKAQj4x8oBCNriygEIsZrLAQjknMsBCKidywEIy5/LARjhmssB",
         "sec-fetch-site: same-origin",
         "sec-fetch-mode: same-origin",
         "sec-fetch-dest: empty",
         "referer: https://www.youtube.com/results?search_query=makup+tips",
         "accept-language: en-US,en;q=0.9",
         "cookie: VISITOR_INFO1_LIVE=ictOoxuWVE0; CONSENT=YES+IN.en+20180529-04-0; PREF=tz=Asia.Calcutta; _gcl_au=1.1.1817841911.1616576748; SID=7gemtYD40-OqTomHokQLcfmHfulz4I50ydT5ganDFGPQ3pyGs3aqzzN_3FzZKGi4gJS4qg.; __Secure-3PSID=7gemtYD40-OqTomHokQLcfmHfulz4I50ydT5ganDFGPQ3pyGpdrBehfpDPe33OIK7YXnYQ.; HSID=Axa9JJtUCsD3Mc14a; SSID=AFFji6J9eAqw6Ats2; APISID=hVjY3VraeBbCjJrS/AhAhfiMkELcxpAhAhfiMkELcxpblIs; SAPISID=nTtdp9k-Af__D-_9/AjtU5Wo2OZiBL2zZv; __Secure-3PAPISID=nTtdp9k-Af__D-_9/AjtU5Wo2OZiBL2zZv; LOGIN_INFO=AFmmF2swRQIgcUlrgDPmk_M2EHey5sEgDH94_7hq7f-yDXh5LSutE8ECIQDHxd8G72XfQ8ne-gs-Cq-qxbNi_6MwhTQ3lqPEJtHfXg:QUQ3MjNmeFdGXzB0aFVQMHNHemR3VEY0YTdaSnNOZ2pfY1R6Y2hJTHVvbTRNSFNKSzNtaTdNRU1tRENRNDhwRnVnTWV1aXRaVFhuTnNCdDlLbjhGZU9uV3NYaDNwMnFPTzFfRHRVMnQzekNGNnFMd3RQRk93NFJEdkwyWU9ValVIbWFHU0VZcWJsLUVIQmZuY1JfNVZRTXlOVTVZS3J5aHVn; YSC=A0hXw0DW_VA; SIDCC=AJi4QfH5ZHPwQIRfr_fs7UbX_zS4oLqMP3m14FsLvKERd8D26e4bQZq4k0iwHRi_odEacBZ4BzU; __Secure-3PSIDCC=AJi4QfFRt2RlmOeX2k5BtH4yVtWk_47lJSavr28S79kFpuiB7iiSD8JcKnDAbTr5AkhWDP2sf_4",
        );
          
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
          
        $dataAyy =array (
        'context' => $resultwwwss,
        'continuation' =>$masterListgh,
        );
          
        curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($dataAyy));
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        
        $resp = curl_exec($curl);
        curl_close($curl);
        
        $resultwww = json_decode($resp , true);
        $content =$resultwww['onResponseReceivedCommands'][0]['appendContinuationItemsAction']['continuationItems'];
        $masterList = $content[1]['continuationItemRenderer']['continuationEndpoint']['continuationCommand']['token'];
        
        $sddf = $content[0]['itemSectionRenderer']['contents'];
        
        foreach($sddf as $ddd){
        $meta = $ddd['videoRenderer'];
        $channelid =$meta['ownerText']['runs'][0]['navigationEndpoint']['browseEndpoint']['browseId'];
        $youtubelink="https://www.youtube.com/channel/".$channelid;
    
        $query="SELECT * FROM channels WHERE channelid='$channelid'";
        $result=mysqli_query($conn , $query);
    
        $search=$_GET['searchinput'];
    
        if(mysqli_num_rows($result)<=0)
        {
            $sql="insert into channels set youtubelink='$youtubelink', channelid='$channelid' , keyword='$search'";
            $result=mysqli_query($conn , $sql);
          
        }
        else{
         $sql="update channels set youtubelink='$youtubelink',channelid='$channelid',keyword='$search' where channelid='$channelid'  ";
         $result=mysqli_query($conn , $sql);
        
        } 
         
        if(!in_array($channelid, $UserChannel)){
            $UserChannel[]=$channelid; 
            channelAbout($channelid,$conn);
            }
        }
          
        if(!empty($masterList) && $rty<50){
        $rty = $rty+1;
        renderDivData($masterList,$rty,$key,$resultwwwss,$UserChannel,$conn);
        
        }else{
        
        }
        }
          $urlww="https://www.youtube.com/results?search_query=".urlencode($search);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $urlww);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('User-Agent: "Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US; rv:1.9.0.15) Gecko/2009101601 Firefox/3.0.15 GTB6 (.NET CLR 3.5.30729)"' ));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        $html = curl_exec($ch);
        
        $first = explode("ytInitialData = {",$html);
        $second = explode(";</script>",$first[1]);
        $result = '{'.$second[0];    //contains json
        $resultwww = json_decode($result , true);
        
        $firstdkey = explode('"innertubeApiKey":"',$html);
        $firstdkeyc = explode('",',$firstdkey[1]);
        $key = $firstdkeyc[0];
        
        $firstd = explode('INNERTUBE_CONTEXT',$html);
$rtt = str_replace('":{"client','{"client',$firstd[1]);
$rtty = str_replace('}}},"','}}}',$rtt);
$json=rtrim($rtty, ',"');
$resultwwwss = json_decode($json , true);
        
        $UserChannel =array();
        
        $endKey =$resultwww['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']
        [1]['continuationItemRenderer']['continuationEndpoint']['continuationCommand']['token'];
    
        if(empty($endKey))
        {
          $endKey =$resultwww['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']
        [2]['continuationItemRenderer']['continuationEndpoint']['continuationCommand']['token'];
        }
        
        if(!in_array($channelid, $UserChannel)){
            $UserChannel[]=$channelid; 
            channelAbout($channelid,$conn);
           }
        
        renderDivData($endKey,$rty,$key,$resultwwwss,$UserChannel,$conn);
        
        
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////
        
        $ch = curl_init();
        $queryw="SELECT * FROM  channels where keyword='$search'";
        $resultw=mysqli_query($conn , $queryw);
    
        if(mysqli_num_rows($resultw)>0)
         {
          while($rowww = mysqli_fetch_assoc($resultw)) {
             
             $uid=$rowww['id'];
             $channelid=$rowww['channelid'];
        $url="https://www.youtube.com/channel/".$channelid."/videos?view=0&sort=dd";
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('User-Agent: "Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US; rv:1.9.0.15) Gecko/2009101601 Firefox/3.0.15 GTB6 (.NET CLR 3.5.30729)"' ));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        $html = curl_exec($ch);
        $first = explode("ytInitialData = {",$html);
        $second = explode(";</script>",$first[1]);
        $result = '{'.$second[0];    //contains json
        $resultwww = json_decode($result , true);
        
        $divv=intval(1);
        
        for($i=0;$i<=29;$i++)
        {
        
          $meta=$resultwww ['contents']['twoColumnBrowseResultsRenderer']['tabs'][1]['tabRenderer']['content']
          ['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]
          ['gridRenderer']['items'][$i]['gridVideoRenderer'];
        
         $videoid=$meta['videoId'];
        
          $durationn=$meta['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']
          ['simpleText'];
          $channelid=$resultwww['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']
          ['endpoint']['browseEndpoint']['browseId'];
          
         
          
          $viewss= str_replace('views','',$meta['viewCountText']['simpleText']);
          $videoviews=intval(str_replace(',','',$viewss));
          
          
           $variable = substr($durationn, 0, strpos($durationn, ":"));
          $duration=intval($variable);
           
          
        
          if($duration>$divv)
           {
          $sql="insert into videoss set videoviews='$videoviews' ,duration='$duration', channelid='$channelid' , videoid='$videoid',keyword='$search'  ";
             $result=mysqli_query($conn , $sql);
           }
        
           else{
             $sql="insert into videoss set reelviews='$videoviews',duration='$duration', channelid='$channelid', videoid='$videoid',keyword='$search' ";
            $result=mysqli_query($conn , $sql);
           
           } 
          }  
        
          }}
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////
        
        $ch = curl_init();
        
        $queryw="SELECT * FROM  videoss where keyword='$search'";
        $resultw=mysqli_query($conn , $queryw);
        if(mysqli_num_rows($resultw)>0)
         {
            while($rowww = mysqli_fetch_assoc($resultw)){
         
                $uid=$rowww['id'];
                $videoid=$rowww['videoid'];
                $duration=$rowww['duration'];    
           $url="https://www.youtube.com/watch?v=".$videoid;
           //$url="https://www.youtube.com/watch?v=zzooJv0kykg";
           curl_setopt($ch, CURLOPT_URL, $url);
           curl_setopt($ch, CURLOPT_HTTPHEADER, array('User-Agent: "Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US; rv:1.9.0.15) Gecko/2009101601 Firefox/3.0.15 GTB6 (.NET CLR 3.5.30729)"' ));
           curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
           curl_setopt($ch, CURLOPT_TIMEOUT, 10);
           $html = curl_exec($ch);
           $first = explode("ytInitialData = {",$html);
           $second = explode(";</script>",$first[1]);
           $result = '{'.$second[0];    //contains json
           $resultwww = json_decode($result , true);
           
           $divv=intval(1);
           
           $meta=$resultwww['contents']['twoColumnWatchNextResults']['results']['results']['contents'][0]
           ['videoPrimaryInfoRenderer']['videoActions']['menuRenderer']['topLevelButtons'];
           
           $likess=str_replace('likes','',$meta[0]['toggleButtonRenderer']['defaultText']
           ['accessibility']['accessibilityData']['label']);
           
            $duration;
           
            $likes=intval(str_replace(',','',$likess));
           
           $dislikess=str_replace('likes','',$meta[1]['toggleButtonRenderer']['defaultText']
           ['accessibility']['accessibilityData']['label']);
           
            $dislikes=intval(str_replace(',','',$dislikess));
            if($duration<=$divv)
            {
             $sql="update videoss set reellikes='$likes' ,reeldislikes='$dislikes' where videoid='$videoid' ";
              $result=mysqli_query($conn , $sql);
              
            }
            else
            {
              $sql="update videoss set videolikes='$likes' ,videodislikes='$dislikes' where videoid='$videoid' ";
              $result=mysqli_query($conn , $sql);
              
            }
              }}
            
              ///////////////////////////////////////////////////////////////////////////////////////////////////////



              $queryw="select * from channels where keyword='$search' ";
            $resultw=mysqli_query($conn , $queryw);
            while($roww=mysqli_fetch_assoc($resultw))
            {
            $channelid=$roww['channelid'];
            $query="select * from videoss where channelid='$channelid'";
            $result=mysqli_query($conn,$query);
            $mount=$total=$totallikes=$totaldislikes=0;
            while($row=mysqli_fetch_assoc($result))
            {
              if(!empty($row['videoviews']))
              {
                $total+=$row['videoviews'];
                $totallikes+=$row['videolikes'];
                $totaldislikes+=$row['videodislikes'];
                $mount++;
                if($mount==12)
                {
                  break;
                }
            }
        }
        if($mount!=0)
        {
        
          
         $avgeviews=$total/$mount;
          
         $avgelikes=$totallikes/$mount;
          
         $avgedislikes=$totaldislikes/$mount;
          
          $sql="update channels set normalvideosavg='$avgeviews',normalvideos='$mount',videoslikesavg='$avgelikes',videosdislikesavg='$avgedislikes'  where channelid='$channelid'";
          $result=mysqli_query($conn , $sql);
        }
        
        }
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////
        
        $queryw="select * from channels where keyword='$search'";
        $resultw=mysqli_query($conn , $queryw);
        while($roww=mysqli_fetch_assoc($resultw))
        {
        $channelid=$roww['channelid'];
        
        $query="select * from videoss where channelid='$channelid'";
        $result=mysqli_query($conn , $query);
        $count=$total=$totallikes=$totaldislikes=0;
        
        while($row=mysqli_fetch_assoc($result))
        {
          if(!empty($row['reelviews']))
          {
             $total+=$row['reelviews'];
             $totallikes+=$row['reellikes'];
             $totaldislikes+=$row['reeldislikes'];
             $count++;
            }
          }
          
          /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
          "total views=>".$total;
          
          "total videos=>".$count;
          
          if($count!=0)
          {
            $avgelikes=$totallikes/$count;
          
          $avgedislikes=$totaldislikes/$count;
          "avreage views=>".$avreageviews=$total/$count;
       $sql="update channels set reelslikesavg='$avgelikes',reelssdislikesavg='$avgedislikes',reelvideos='$count',reelvideosavg='$avreageviews'  where channelid='$channelid'";
          $result=mysqli_query($conn , $sql);
          
          
          }
          
          }
    



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
 <div class="container">
<div class="row">
<div class="col-sm-4">
<a href="exportdata.php" class="btn btn-success pull-right">Export Data into csv</a>
<table class="table table-bordered">
                <thead>
                    <tr>
                    <th>ID</th>
                      <th>channelname</th>
                      <th>channelabout</th>
                      <th>email</th>
                      <th>phoneno</th>
                      <th>subscribers</th>
                      <th>youtubelink</th>
                      <th>location</th>
                      <th>no of long videos</th>
                      <th>no of reels</th>
                      <th>long video views(avg)</th>
                      <th>reels views(avg)</th>
                      <th>long video likes(avg)</th>
                      <th>long video dislikes(avg)</th>
                      <th>reels video likes(avg)</th>
                      <th>reels video dislikes(avg)</th>
                      <th>facebook link</th>
                      <th>twitter link</th>
                      <th>instagram link</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                    
                    include 'connection.php';
                    $query="SELECT * FROM channels where keyword='$search' ";
                    $result=mysqli_query($conn , $query);
                    if(mysqli_num_rows($result) > 0){ 
                        while($row =mysqli_fetch_assoc($result)){ ?>                
                    <tr>
                    <td><?php echo $row['id']; ?></td>
                      <td><?php echo $row['channelname']; ?></td>
                      <td><?php echo $row['channelabout']; ?></td>
                      <td><?php echo $row['email']; ?></td>
                      <td><?php echo $row['phoneno']; ?></td>
                      <td><?php echo $row['subscribers']; ?></td>
                      <td><?php echo $row['youtubelink']; ?></td>
                      <td><?php echo $row['location']; ?></td>
                      <td><?php echo $row['normalvideos']; ?></td>
                      <td><?php echo $row['reelvideos']; ?></td>
                      <td><?php echo $row['normalvideosavg']; ?></td>
                      <td><?php echo $row['reelvideosavg']; ?></td>
                      <td><?php echo $row['videoslikesavg']; ?></td>
                      <td><?php echo $row['videosdislikesavg']; ?></td>
                      <td><?php echo $row['reelslikesavg']; ?></td>
                      <td><?php echo $row['reelssdislikesavg']; ?></td>
                      <td><?php echo $row['fblink']; ?></td>
                      <td><?php echo $row['twitterlink']; ?></td>
                      <td><?php echo $row['instalink']; ?></td>
                      
                    <?php }} ?>
                </tbody>
            </table>
</div>
<div class="col-sm-4">
</div>

<div class="col-sm-4">
</div>


</div> 
</div>  
</body>
</html>



   
                                             
