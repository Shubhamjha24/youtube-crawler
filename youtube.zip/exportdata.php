<?php
include 'connection.php';
$query="SELECT * FROM channels ORDER BY id ";
$result=mysqli_query($conn , $query);
if(mysqli_num_rows($result) > 0){ 
$delimiter = ",";
$filename = "youtubedata". ".csv";
$f = fopen('php://memory', 'w');
$fields = array('ID', 'channelname', 'channelabout', 'email', 'phoneno', 'subscribers','youtubelink','location','no of long videos',
'no of reels','long video views(avg)','reels views(avg)','long video likes(avg)','long video dislikes(avg)','reels video likes(avg)','reels video dislikes(avg)',
'fblink','twitterlink','instalink');
fputcsv($f, $fields, $delimiter);
    
 while($row =mysqli_fetch_assoc($result)){
        
        $lineData = array($row['id'],
        $row['channelname'],
        $row['channelabout'],
        $row['email'],
        $row['phoneno'],
        $row['subscribers'],
        $row['youtubelink'],
        $row['location'],
        $row['normalvideos'],
        $row['reelvideos'],
        $row['normalvideosavg'],
        $row['reelvideosavg'],
        $row['videoslikesavg'],
        $row['videosdislikesavg'],
        $row['reelslikesavg'],
        $row['reelssdislikesavg'],
        $row['fblink'],
        $row['twitterlink'],
        $row['instalink']
    );
        fputcsv($f, $lineData, $delimiter);
    }
    
    
    fseek($f, 0);
    
    
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="' . $filename . '";');
    
    
    fpassthru($f);
}
exit;

?>