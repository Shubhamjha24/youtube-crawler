<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
 <div class="container">
<div class="row">
<div class="col-sm-4">
<a href="exportdata.php" class="btn btn-success pull-right">Export Data into csv</a>
<table class="table table-bordered">
                <thead>
                    <tr>
                    <th>ID</th>
                      <th>channelname</th>
                      <th>channelabout</th>
                      <th>email</th>
                      <th>phoneno</th>
                      <th>subscribers</th>
                      <th>youtubelink</th>
                      <th>location</th>
                      <th>no of long videos</th>
                      <th>no of reels</th>
                      <th>long video views(avg)</th>
                      <th>reels views(avg)</th>
                      <th>long video likes(avg)</th>
                      <th>long video dislikes(avg)</th>
                      <th>reels video likes(avg)</th>
                      <th>reels video dislikes(avg)</th>
                      <th>facebook link</th>
                      <th>twitter link</th>
                      <th>instagram link</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                    
                    include 'connection.php';
                    $search=urlencode($_GET['searchinput']);
                    $query="SELECT * FROM channels where keyword='$search' ";
                    $result=mysqli_query($conn , $query);
                    if(mysqli_num_rows($result) > 0){ 
                        while($row =mysqli_fetch_assoc($result)){ ?>                
                    <tr>
                    <td><?php echo $row['id']; ?></td>
                      <td><?php echo $row['channelname']; ?></td>
                      <td><?php echo $row['channelabout']; ?></td>
                      <td><?php echo $row['email']; ?></td>
                      <td><?php echo $row['phoneno']; ?></td>
                      <td><?php echo $row['subscribers']; ?></td>
                      <td><?php echo $row['youtubelink']; ?></td>
                      <td><?php echo $row['location']; ?></td>
                      <td><?php echo $row['normalvideos']; ?></td>
                      <td><?php echo $row['reelvideos']; ?></td>
                      <td><?php echo $row['normalvideosavg']; ?></td>
                      <td><?php echo $row['reelvideosavg']; ?></td>
                      <td><?php echo $row['videoslikesavg']; ?></td>
                      <td><?php echo $row['videosdislikesavg']; ?></td>
                      <td><?php echo $row['reelslikesavg']; ?></td>
                      <td><?php echo $row['reelssdislikesavg']; ?></td>
                      <td><?php echo $row['fblink']; ?></td>
                      <td><?php echo $row['twitterlink']; ?></td>
                      <td><?php echo $row['instalink']; ?></td>
                      
                    <?php }} ?>
                </tbody>
            </table>
</div>
<div class="col-sm-4">
</div>

<div class="col-sm-4">
</div>


</div> 
</div>  
</body>
</html>